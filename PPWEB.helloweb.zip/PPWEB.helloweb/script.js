var $tabs= $('.tabs');
var $panels = $('.panels');

$tabs.on('click', 'a', function (e) ) {
    e.preventDefault();
    
    var id=$(this).attr ('href');
    
    $panels.filter('[aria-hidden="false]"').attr('aria-hidden',true);
    $tabs.find ('[aria-selected="true"]').attr('aria-selected', false);
    
    $(this).attr('aria-selected', true);
    $(id).attr('aria-hidden', false);
    
}